#pragma once
#include "CoreBase.h"
#include "GraphicsBackend.h"
#include "GraphicsTypes.h"

struct VERTICE {
    float x;
    float y;
    int BrushSize;
};

struct EDGE {
    std::vector<VERTICE> vertices;
};

struct LINE {
    PointF startPoint;
    PointF endPoint;
};

struct FLOATPOINT {
    float x;
    float y;
};

struct LOCATION {
    float x;
	float y;
};

struct ROTATION {
	float angle;
	float centerX;
	float centerY;
};

struct SCALE {
    float x;
    float y;
};

struct TRANSFORM {
    LOCATION location;
    ROTATION rotation;
    SCALE scale;
};

struct ACTION {
    int Id;
    int TargetID;
    bool LastMovedPosition = false;
    int Tool;
    int Layer;
    int FrameIndex;
    int isLayerVisible;
    RectF Position;
    EDGE FreeForm;
    EllipseF Ellipse;
    COLORREF FillColor;
    COLORREF Color;
    LINE Line;
    int BrushSize;
    bool IsFilled;
    bool isPixelMode;
    int mouseX;
    int mouseY;
    std::vector<FLOATPOINT> pixelsToFill;
    int PaintTarget;

	TRANSFORM TransformProperties;

    std::wstring Text;
    float TextWidth;
    float TextHeight;
    std::wstring FontFamily;   // e.g. "Arial"
    int FontSize;              // in DIPs (or tenths of a point if you prefer)
    int FontWeight;            // map to DWRITE_FONT_WEIGHT
    bool FontItalic;
    bool FontUnderline;
    bool FontStrike;
};

struct DELTA {
	float deltaX;
	float deltaY;
};

struct Layer {
    int LayerID;
    int FrameIndex;
    bool isActive;
    bool isVisible;
    RenderSurfacePtr surfaceHandle;
    BitmapSurfacePtr bitmapHandle;
};

struct LayerOrder {
    int layerOrder;
    int layerIndex;
};

struct LineData {
    bool isClosed;
    int index;
};

struct LineGeometry {
    std::vector<PointF> closedLoop;
    COLORREF fillColor;
};

struct PIXEL {
    int x;
    int y;

    bool operator==(const PIXEL& other) const {
        return x == other.x && y == other.y;
    }
};

namespace std {
    template <>
    struct hash<PIXEL> {
        size_t operator()(const PIXEL& p) const {
            return std::hash<int>()(p.x) ^ (std::hash<int>()(p.y) << 1);
        }
    };
}

struct LayerButton {
    int LayerID;
    int FrameIndex;
    HWND button;
    bool isActive;
    RenderSurfacePtr surfaceHandle;
};

struct TimelineFrameButton {
    int LayerIndex;
    int FrameIndex; 
    HWND frame;
    RenderSurfacePtr surfaceHandle;
};

struct PairHash {
    template <typename T1, typename T2>
    std::size_t operator()(const std::pair<T1, T2>& p) const {
        auto h1 = std::hash<T1>{}(p.first);
        auto h2 = std::hash<T2>{}(p.second);
        return h1 ^ (h2 << 1);
    }
};

