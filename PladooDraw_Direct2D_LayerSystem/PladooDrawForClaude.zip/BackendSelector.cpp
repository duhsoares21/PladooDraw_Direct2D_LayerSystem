#include "pch.h"
#include "BackendSelector.h"
#include "OpenGLBackend.h"

std::unique_ptr<IGraphicsBackend> CreateGraphicsBackend() {
    //return std::make_unique<Direct2DBackend>();
    return std::make_unique<OpenGLBackend>();
}
